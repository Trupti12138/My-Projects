function toggleMenu() {
  const menu = document.querySelector(".menu-links");
  const icon = document.querySelector(".hamburger-icon");
  menu.classList.toggle("open");
  icon.classList.toggle("open");
}

document.addEventListener("DOMContentLoaded", function () {
  // Dark mode toggle
  const toggleBtn = document.createElement("button");
  toggleBtn.innerText = "Toggle Dark Mode";
  toggleBtn.classList.add("btn", "btn-color-2");
  document.querySelector(".btn-container").appendChild(toggleBtn);

  toggleBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");
  });

  // Button click event
  document.querySelectorAll(".btn").forEach(button => {
      button.addEventListener("click", () => {
          alert(`You clicked: ${button.innerText}`);
      });
  });

  // Social media icon hover effect
  document.querySelectorAll(".icon").forEach(icon => {
      icon.addEventListener("mouseenter", () => {
          icon.style.transform = "scale(1.2)";
      });

      icon.addEventListener("mouseleave", () => {
          icon.style.transform = "scale(1)";
      });
  });
});

// Dark mode styles (you can add this in your CSS file)
const style = document.createElement("style");
style.innerHTML = `
  .dark-mode {
      background-color: #121212;
      color: white;
  }
`;
document.head.appendChild(style);













// Animate skills on hover
const skillBoxes = document.querySelectorAll(".details-container");
skillBoxes.forEach((box) => {
  box.addEventListener("mouseover", function () {
      this.style.backgroundColor = "#e6f7ff"; // Light Blue
  });

  box.addEventListener("mouseout", function () {
      this.style.backgroundColor = "white";
  });
});













document.getElementById("contact-form").addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent form from actually submitting

  // Show alert box
  alert("Your message has been sent successfully!");

  // Clear form fields
  document.getElementById("name").value = "";
  document.getElementById("email").value = "";
  document.getElementById("message").value = "";
});
